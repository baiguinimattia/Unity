# Unity Tutorial: Survival Shooter

**📖 Tutorial:**
[https://unity3d.com/learn/tutorials/projects/survival-shooter-tutorial](https://unity3d.com/learn/tutorials/projects/survival-shooter-tutorial)

**⚙️ Source:**
[https://github.com/lukearmstrong/unity-tutorial-survival-shooter](https://github.com/lukearmstrong/unity-tutorial-survival-shooter)
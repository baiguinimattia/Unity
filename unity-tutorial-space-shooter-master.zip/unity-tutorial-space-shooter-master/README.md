# Unity Tutorial: Space Shooter

**👾 Play Game:**
[http://lukearmstrong.co.uk/games/unity-tutorial-space-shooter](http://lukearmstrong.co.uk/games/unity-tutorial-space-shooter)

**📖 Tutorial:**
[https://unity3d.com/learn/tutorials/projects/space-shooter-tutorial](https://unity3d.com/learn/tutorials/projects/space-shooter-tutorial)

**⚙️ Source:**
[https://github.com/lukearmstrong/unity-tutorial-space-shooter](https://github.com/lukearmstrong/unity-tutorial-space-shooter)
